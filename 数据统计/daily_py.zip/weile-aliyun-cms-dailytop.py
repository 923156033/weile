#!/usr/local/bin/python3
# -*- coding: utf-8 -*-

from aliyunsdkcore.client import AcsClient
from aliyunsdkecs.request.v20140526.DescribeInstancesRequest import DescribeInstancesRequest
from aliyunsdkcms.request.v20190101.DescribeMetricTopRequest import DescribeMetricTopRequest
import datetime
import xlsxwriter
import json

client = AcsClient()

def get_ecs_data():
    request = DescribeInstancesRequest()
    request.set_accept_format('json')
    request.set_PageSize('100')
    ecs_dict = json.loads(client.do_action_with_exception(request))
    TotalCount = ecs_dict.get('TotalCount')
    PageNum = TotalCount // 100 + 1
    num = 0
    _set = []
    while num < PageNum:
        num += 1
        request.add_query_param('PageNumber', num)
        ecs_dict = json.loads(client.do_action_with_exception(request))
        Instances = ecs_dict.get('Instances').get('Instance')
        _set += Instances
    return _set

def get_cms_top(MetricName):
    StartTime = (datetime.datetime.now() - datetime.timedelta(days=1)).strftime('%Y-%m-%d 00:00:00')
    EndTime = datetime.datetime.now().strftime('%Y-%m-%d 00:00:00')
    request = DescribeMetricTopRequest()
    request.set_accept_format('json')
    request.set_Namespace("acs_ecs_dashboard")
    request.set_Orderby("Average")
    request.set_Period("60")
    request.set_StartTime(StartTime)
    request.set_EndTime(EndTime)
    request.set_MetricName(MetricName)
    request.set_Length("1000")
    cms_dict = json.loads(client.do_action_with_exception(request))
    Datapoints = json.loads(cms_dict.get('Datapoints'))
    return Datapoints

def insert_xls_data():
    i = 1
    Instances = get_ecs_data()
    Datapoints = get_cms_top(Metric)
    for Datapoint in Datapoints:
        i += 1
        sheet.write(i, 0, Datapoint.get('order'))
        sheet.write(i, 1, Datapoint.get('instanceId'))
        for Instance in Instances:
            IpAddress = Instance.get('NetworkInterfaces').get('NetworkInterface')[0].get('PrimaryIpAddress')
            try:
                Tags = Instance.get('Tags').get('Tag')
                for Tag in Tags:
                    if Tag.get('TagKey') == 'type':
                        TagValue = Tag.get('TagValue')
            except:
                TagValue = Instance.get('Tags')
            if Instance.get('InstanceId') == Datapoint.get('instanceId'):
                sheet.write(i, 2, Instance.get('InstanceName'))
                sheet.write(i, 3, IpAddress)
                sheet.write(i, 4, TagValue)
        if Metric == 'cpu_total' or Metric == 'memory_usedutilization':
            sheet.write(i, 5, Datapoint.get('Average'))
            sheet.write(i, 6, Datapoint.get('Minimum'))
            sheet.write(i, 7, Datapoint.get('Maximum'))
        elif Metric == 'networkin_rate' or Metric == 'networkout_rate':
            sheet.write(i, 5, round(Datapoint.get('Average') / 1024 / 1024,2))
            sheet.write(i, 6, round(Datapoint.get('Minimum') / 1024 / 1024,2))
            sheet.write(i, 7, round(Datapoint.get('Maximum') / 1024 / 1024,2))
        else:
            print('输入的监控项值未获取:{}'.format(Metric))

if __name__ == '__main__':
    StartTime = (datetime.date.today() - datetime.timedelta(days=1)).strftime('%y年%m月%d日')
    EndTime = datetime.date.today().strftime('%y年%m月%d日')
    xlsx = xlsxwriter.Workbook('weile_aliyun_MetricTop{}.xlsx'.format(datetime.date.today() - datetime.timedelta(days=1)))  #创建微乐xlsx文件
    cell_format_blue = xlsx.add_format({'bold': False, 'font_color': 'blue'})
    cell_format_red = xlsx.add_format({'bold': False, 'font_color': 'red'})
    MetricNames = ['cpu_total', 'memory_usedutilization','networkin_rate','networkout_rate']
    for Metric in MetricNames:
        sheet = xlsx.add_worksheet(Metric)
        sheet.write(0, 0, '取值时间: {}0点~{}0点'.format(StartTime, EndTime), cell_format_red)
        sheet.write(1, 0, 'order', cell_format_blue)
        sheet.write(1, 1, 'instanceId', cell_format_blue)
        sheet.write(1, 2, 'instanceName', cell_format_blue)
        sheet.write(1, 3, 'IpAddress', cell_format_blue)
        sheet.write(1, 4, 'TagValue', cell_format_blue)
        sheet.write(1, 5, 'Average', cell_format_blue)
        sheet.write(1, 6, 'Minimum', cell_format_blue)
        sheet.write(1, 7, 'Maximum', cell_format_blue)
        if Metric == 'cpu_total' or Metric == 'memory_usedutilization':
            sheet.write(0, 5, '数值单位：%', cell_format_red)
        elif Metric == 'networkin_rate' or Metric == 'networkout_rate':
            sheet.write(0, 5, '数值单位：Mb/s', cell_format_red)
        insert_xls_data()
    xlsx.close()
